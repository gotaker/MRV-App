import { ColumnNameConfig } from './column-name-config';

describe('ColumnNameConfig', () => {
  it('should create an instance', () => {
    expect(new ColumnNameConfig()).toBeTruthy();
  });
});
