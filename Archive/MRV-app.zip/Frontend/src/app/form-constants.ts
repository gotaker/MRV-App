export  class FormConstants {
     public static NDC_CAUSE = "ndcCause";
     public static VALUE = "value";
     public static NDC_AREA = "area";
     public static LOCATION = "location";
     public static FUNDING = "funding";
}
