export interface SectorDetailsRequest {
    menuId :string;
    sector ?:string;
    category ?:string;
    subSector ?:string;
    subCategory ?:string;
}
