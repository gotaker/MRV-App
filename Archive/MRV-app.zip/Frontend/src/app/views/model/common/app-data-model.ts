export interface AppDataModel {
  element: string;
  key: string;
  value: any;
  label: string;
}
