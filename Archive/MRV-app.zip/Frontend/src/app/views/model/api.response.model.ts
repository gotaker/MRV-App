export interface ApiResponseModel{
    statusCode:number;
    message:string;
    data:any;
}