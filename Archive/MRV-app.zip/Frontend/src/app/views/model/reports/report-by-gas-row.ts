export interface ReportByGasRow {
    label:string;
    cssClass:string;
    co2:number;
    ch4:number;
    n2o:number;
    co2eq: number;
}
