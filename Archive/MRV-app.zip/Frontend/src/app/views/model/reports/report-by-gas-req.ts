export interface ReportByGasReq {
    fromYear:number;
    toYear:number;
    inventoryUnit:string;
}
