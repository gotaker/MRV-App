import { QuestionModel } from "./question-model";

export class Question2Model {
    label:string;
    questions?:QuestionModel[];
}