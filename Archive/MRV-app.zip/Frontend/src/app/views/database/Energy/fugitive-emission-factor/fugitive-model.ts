export interface Fugitive {
    category:string;
    subCategory:string;
    source:string;
    efch4:number;
    efco2:number;
    efn2o:number;
    unit:string;
    reference:string;
    type:string;
}