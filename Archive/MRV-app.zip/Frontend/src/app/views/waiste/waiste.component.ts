import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiste',
  templateUrl: './waiste.component.html',
  styleUrls: ['./waiste.component.scss']
})
export class WaisteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
