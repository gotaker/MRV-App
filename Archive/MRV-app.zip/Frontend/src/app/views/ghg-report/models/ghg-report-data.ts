export interface GhgReportData {
    A:string;
    B ?:string;
    C ?:string;
    D ?:string;
    E ?:string;
    F ?:string;
    G ?:string;
    H ?:string;
}
