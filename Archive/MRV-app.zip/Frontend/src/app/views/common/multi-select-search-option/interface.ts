export interface SelectData {
    id: string;
    name: string;
}