export const environment = {
  production: false,
  apiBasePath:'http://103.16.222.141:3000',
};
