export const environment = {
  production: false,
  apiBasePath:'http://localhost:3000',
};
